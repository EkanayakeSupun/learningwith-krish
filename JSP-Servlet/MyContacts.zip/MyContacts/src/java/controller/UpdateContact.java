/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Contact;
import model.Db;
import model.Functions;

/**
 *
 * @author ekana
 */
@WebServlet(name = "UpdateContact", urlPatterns = {"/update"})
public class UpdateContact extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String nm = request.getParameter("cName");
        String con = request.getParameter("contact");
        String oCon = request.getParameter("oContact");
        String btn = request.getParameter("save");
  if(nm!=null && !nm.isEmpty()){
//        if (btn != null && !btn.isEmpty() && btn != "") {
            Contact c = new Contact(nm, con);
            Db db = Functions.readData();
            if (db != null) {
                boolean canUpdate = true;
                ArrayList<Contact> cList = db.getContactsList();
                for (int i = 0; i < cList.size(); i++) {
                    if (cList.get(i).getContact().equals(con)) {
                        canUpdate = false;
                    }
                }
                if (canUpdate) {
                    db.update(c, oCon);
                    Functions.saveData(db);
                    request.getSession().setAttribute("msgs", "Succesfully Updated"); 
                } else {
                    request.getSession().setAttribute("msge", "Error"); 
                }
            }else{
                    request.getSession().setAttribute("msge", "Error");
            }
    }else{
                      request.getSession().setAttribute("msge", "Error");
  }

        
        response.sendRedirect("newcontact.jsp");
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
