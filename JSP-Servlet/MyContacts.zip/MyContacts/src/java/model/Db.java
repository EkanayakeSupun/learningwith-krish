/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.io.Serializable;
import java.util.ArrayList;

/**
 *
 * @author ekana
 */
public class Db implements Serializable {

    private ArrayList<Contact> contactList = new ArrayList<>();

    public ArrayList<Contact> getContactsList() {
        return contactList;
    }

    public String addContact(Contact contact) {
        ArrayList<Contact> searchContact = searchContact(contact.getName());
        if (searchContact.size() == 0) {
            this.contactList.add(contact);
            return "Successfully Added";
        } else {
            return "Already exist";
        }
    }

    public ArrayList<Contact> searchContact(String nameORcontact) {
        ArrayList<Contact> temp = new ArrayList<>();
        for (int i = 0; i < contactList.size(); i++) {
            if (contactList.get(i).getContact().startsWith(nameORcontact) || contactList.get(i).getName().toUpperCase().startsWith(nameORcontact.toUpperCase())) {
                temp.add(contactList.get(i));
            }
        }
        return temp;
    }

    public void delete(String contact){
     for (int i = 0; i < contactList.size(); i++) {
            if (contactList.get(i).getContact().equals(contact)) {
                contactList.remove(i);
            }
        }
    }
    public void update(Contact contact, String oCon){
           System.out.println("Size########################"+contactList.size());
           int con=-1;
     for (int i = 0; i < contactList.size(); i++) {
            if (contactList.get(i).getContact().equals(oCon)) {
                 con=i;
                System.out.println("************************************"+i);
//                break;
            }
        }
     if(con>=0){
                contactList.add(con, contact);
                contactList.remove(con+1);
     }
    }
}
