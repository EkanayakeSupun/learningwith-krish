/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

/**
 *
 * @author ekana
 */
public class Functions {
    public static void saveData(Db db){
        try {
            File f=new File("data.data");
            ObjectOutputStream o=new ObjectOutputStream(new FileOutputStream(f));
            o.writeObject(db);
            o.flush();
            o.close();
        } catch (Exception e) {
//            lgr.error(" --> " + e);
            e.printStackTrace();
        }
    }
    
    public static Db readData(){
        Db db=null;
        try {
                     File f=new File("data.data");
                     ObjectInputStream in=new ObjectInputStream(new FileInputStream(f));
                      db=(Db)in.readObject();
                      in.close();
                     
        } catch (Exception e) {
            e.printStackTrace();
        }
        return db;
    }
}
