/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.util.ArrayList;

/**
 *
 * @author ekana
 */
public class NewClass {
    public static void main(String[] args) {
   ArrayList<String> al=new ArrayList<>();
   al.add("A");
   al.add("B");
   al.add("C");
   al.add("D");
   
        for (String a:al) {
            System.out.println(a);
        }
        
        System.out.println("After....");
        
        String get = al.get(2);
    get="C2";
    al.add(2, get);
    al.remove(3);
    for(String a:al){
        System.out.println(a);
    }
    }
}
