function signIn() {
    alert("OK");
    var mobile = document.getElementById("m").value;
    var name = document.getElementById("n").value;
    var country = document.getElementById("c").value;

    var request = new XMLHttpRequest();

    request.onreadystatechange = function () {
        if (request.readyState === 4) {
            if (request.status === 200) {
                var resp = request.responseText;
                alert(resp);
                window.location = "Home.jsp";
            }
        }
    }

    request.open("POST", "Sign_In", true);
    request.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    request.send("m=" + mobile + "&n=" + name + "&c=" + country);
}

function sendMessage() {

    var nu = document.getElementById("no").value;
    var msg = document.getElementById("msg").value;
    var req = new XMLHttpRequest();
    req.onreadystatechange = function () {
        if (req.readyState === 4) {
            if (req.status === 200) {
                var re = req.responseText;
            }
        }
    }
    req.open("GET", "Servlet_View?n=" + nu + "&m=" + msg, true);
    req.send();
}

function loadMessage() {
    var req = new XMLHttpRequest();
    req.onreadystatechange = function () {
        if (req.readyState === 4) {
            if (req.status === 200) {
                var resp = req.responseText;
                document.getElementById("di").innerHTML = resp;
            }

        }
    }
    req.open("GET", "Load_Message.jsp", true);
    req.send();
}

function signOut() {
    alert("OK");
    var req = new XMLHttpRequest();
    req.open("GET", "SignOut", true);
    req.send();
    req.onreadystatechange = function () {
        if (req.readyState === 4) {
            if (req.status === 200) {
                var resp = req.responseText;
                if (resp === "Success") {
                    window.location = "SignIn.jsp";
                } else {
                }
            }
        }
    }
}